import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ArrowLeft, Play, LogOut, Zap, Bot } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

interface AttackOption {
  id: string;
  name: string;
  command: string;
}

const attackOptions: AttackOption[] = [
  { id: "1", name: "Ultimate Crash", command: "ultimatecrash" },
  { id: "2", name: "Crash Invisible", command: "crashinvisible" },
  { id: "3", name: "Hard Delay Invisible", command: "harddelayinvisible" },
  { id: "4", name: "iOS Crash (Exp)", command: "ioscrash" },
  { id: "5", name: "Android UI Killer", command: "androiduikiller" },
  { id: "6", name: "Bug Ghost FC", command: "ghostfc" },
  { id: "7", name: "Invisible Crash", command: "invisiblecrash" },
  { id: "8", name: "AXR Delay", command: "axrdelay" },
  { id: "9", name: "Infinity Crash", command: "infinitycrash" },
];

export default function AttackMenu() {
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();
  const [targetNumber, setTargetNumber] = useState("");
  const [selectedAttack, setSelectedAttack] = useState("");
  const [statusMessage, setStatusMessage] = useState("");

  const sendAttackMutation = useMutation({
    mutationFn: async ({ command, targetNumber }: { command: string; targetNumber: string }) => {
      const response = await apiRequest("POST", "/api/send-telegram", {
        command,
        targetNumber,
      });
      return response.json();
    },
    onSuccess: (data) => {
      setStatusMessage(data.message);
      toast({
        title: "Success",
        description: data.message,
      });
      // Reset form after successful send
      setTimeout(() => {
        setTargetNumber("");
        setSelectedAttack("");
        setStatusMessage("");
      }, 3000);
    },
    onError: (error) => {
      const errorMessage = error.message || "Failed to send attack command";
      setStatusMessage(errorMessage);
      toast({
        title: "Error",
        description: errorMessage,
        variant: "destructive",
      });
    },
  });

  const handleSendAttack = () => {
    if (!selectedAttack) {
      setStatusMessage("Please select an attack option!");
      return;
    }
    
    if (!targetNumber) {
      setStatusMessage("Please enter a target number!");
      return;
    }

    // Validate phone number format
    const phoneRegex = /^[\+]?[1-9][\d]{7,14}$/;
    const cleanPhone = targetNumber.replace(/[\s\-\(\)]/g, "");
    
    if (!phoneRegex.test(cleanPhone)) {
      setStatusMessage("Please enter a valid phone number!");
      return;
    }

    const selectedOption = attackOptions.find(option => option.id === selectedAttack);
    if (!selectedOption) {
      setStatusMessage("Invalid attack option selected");
      return;
    }

    const formattedNumber = targetNumber.replace(/[^\d+]/g, "");
    sendAttackMutation.mutate({
      command: selectedOption.command,
      targetNumber: formattedNumber,
    });
  };

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  return (
    <div className="min-h-screen bg-black text-cyan-400 flex flex-col">
      {/* Background Animation */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-cyan-400/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-48 h-48 bg-blue-600/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-3/4 left-3/4 w-32 h-32 bg-cyan-400/10 rounded-full blur-3xl animate-pulse delay-2000"></div>
      </div>

      {/* Header */}
      <div className="bg-gradient-to-r from-cyan-400 to-blue-600 text-black px-6 py-4 shadow-2xl relative z-10">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <ArrowLeft className="w-6 h-6 mr-4 cursor-pointer hover:scale-110 transition-transform" />
            <h1 className="text-xl font-bold font-orbitron tracking-wider">ATTACK MENU</h1>
          </div>
          <div className="flex items-center gap-2">
            <Link href="/bot-admin">
              <Button
                variant="outline"
                size="sm"
                className="bg-black/20 border-black/30 text-black hover:bg-black/30"
              >
                <Bot className="w-4 h-4 mr-2" />
                BOT ADMIN
              </Button>
            </Link>
            <Button
              onClick={handleLogout}
              variant="outline"
              size="sm"
              className="bg-black/20 border-black/30 text-black hover:bg-black/30"
              disabled={logoutMutation.isPending}
            >
              <LogOut className="w-4 h-4 mr-2" />
              LOGOUT
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col items-center justify-center p-8 relative z-10">
        <Card className="w-full max-w-md bg-black/80 border-2 border-cyan-400 shadow-2xl backdrop-blur-sm">
          <CardContent className="p-8">
            {/* Logo */}
            <div className="text-center mb-8">
              <div className="w-24 h-24 mx-auto bg-gradient-to-br from-cyan-400 to-blue-600 rounded-full flex items-center justify-center mb-4 shadow-2xl">
                <Zap className="w-12 h-12 text-black" />
              </div>
              <h2 className="text-2xl font-bold font-orbitron tracking-wider text-cyan-400">
                ATTACK MENU
              </h2>
            </div>

            {/* Target Number Input */}
            <div className="mb-6">
              <Input
                type="text"
                placeholder="Target number [e.g. +62 812xxxx]"
                value={targetNumber}
                onChange={(e) => setTargetNumber(e.target.value)}
                className="bg-transparent border-2 border-cyan-400 text-cyan-400 placeholder:text-cyan-400/60 focus:border-cyan-400 focus:ring-cyan-400/50 h-12 font-orbitron"
              />
            </div>

            {/* Attack Selection */}
            <div className="mb-6">
              <Select value={selectedAttack} onValueChange={setSelectedAttack}>
                <SelectTrigger className="bg-transparent border-2 border-cyan-400 text-cyan-400 focus:border-cyan-400 focus:ring-cyan-400/50 h-12 font-orbitron">
                  <SelectValue placeholder="SELECT MENU ▼" />
                </SelectTrigger>
                <SelectContent className="bg-black/90 border-2 border-cyan-400 backdrop-blur-sm">
                  {attackOptions.map((option) => (
                    <SelectItem
                      key={option.id}
                      value={option.id}
                      className="text-cyan-400 focus:bg-cyan-400/20 focus:text-cyan-400 cursor-pointer"
                    >
                      {option.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Send Button */}
            <Button
              onClick={handleSendAttack}
              disabled={sendAttackMutation.isPending}
              className="w-full h-12 bg-gradient-to-r from-cyan-400 to-blue-600 hover:from-cyan-500 hover:to-blue-700 text-black font-bold font-orbitron tracking-wider transition-all duration-300 shadow-lg hover:shadow-xl"
            >
              {sendAttackMutation.isPending ? (
                <>
                  SENDING...
                  <div className="ml-2 w-4 h-4 border-2 border-black/30 border-t-black rounded-full animate-spin"></div>
                </>
              ) : (
                <>
                  SEND BUG
                  <Play className="w-4 h-4 ml-2" />
                </>
              )}
            </Button>

            {/* Status Message */}
            {statusMessage && (
              <div className="mt-4 p-3 text-center text-sm font-orbitron border border-cyan-400/30 rounded-lg bg-cyan-400/10 backdrop-blur-sm">
                {statusMessage}
              </div>
            )}
          </CardContent>
        </Card>

        {/* User Info */}
        <div className="mt-8 text-center text-cyan-400/70">
          <p className="font-orbitron">Welcome back, <span className="text-cyan-400">{user?.username}</span></p>
        </div>
      </div>
    </div>
  );
}
