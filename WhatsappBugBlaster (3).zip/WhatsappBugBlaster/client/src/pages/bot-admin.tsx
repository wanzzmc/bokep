import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Bot, Settings, Copy, CheckCircle, XCircle, ArrowLeft } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

export default function BotAdmin() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [webhookUrl, setWebhookUrl] = useState("");

  // Query bot status
  const { data: botStatus, isLoading } = useQuery({
    queryKey: ["/api/bot-status"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/bot-status");
      return response.json();
    },
  });

  // Setup webhook mutation
  const setupWebhookMutation = useMutation({
    mutationFn: async (url: string) => {
      const response = await apiRequest("POST", "/api/setup-bot-webhook", {
        webhookUrl: url,
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Webhook setup successfully",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleSetupWebhook = () => {
    if (!webhookUrl) {
      toast({
        title: "Error",
        description: "Please enter a webhook URL",
        variant: "destructive",
      });
      return;
    }
    setupWebhookMutation.mutate(webhookUrl);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied",
      description: "Text copied to clipboard",
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-black text-cyan-400 flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-cyan-400"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-black text-cyan-400 p-8">
      {/* Background Animation */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-cyan-400/10 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-48 h-48 bg-blue-600/10 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      <div className="max-w-4xl mx-auto relative z-10">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Link href="/">
            <Button
              variant="ghost"
              size="sm"
              className="text-cyan-400 hover:bg-cyan-400/10"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Attack Menu
            </Button>
          </Link>
        </div>
        
        <div className="text-center mb-8">
          <div className="w-16 h-16 mx-auto bg-gradient-to-br from-cyan-400 to-blue-600 rounded-full flex items-center justify-center mb-4">
            <Bot className="w-8 h-8 text-black" />
          </div>
          <h1 className="text-3xl font-bold font-orbitron tracking-wider text-cyan-400">
            TELEGRAM BOT ADMIN
          </h1>
          <p className="text-cyan-400/70 mt-2">
            Welcome back, <span className="text-cyan-400">{user?.username}</span>
          </p>
        </div>

        {/* Bot Status Card */}
        <Card className="mb-8 bg-black/80 border-2 border-cyan-400 shadow-2xl">
          <CardHeader>
            <CardTitle className="text-cyan-400 font-orbitron flex items-center">
              <Settings className="w-5 h-5 mr-2" />
              Bot Configuration Status
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center justify-between">
                <span>Bot Token:</span>
                <Badge
                  variant={botStatus?.botConfigured ? "default" : "destructive"}
                  className={botStatus?.botConfigured ? "bg-green-600" : "bg-red-600"}
                >
                  {botStatus?.botConfigured ? (
                    <CheckCircle className="w-3 h-3 mr-1" />
                  ) : (
                    <XCircle className="w-3 h-3 mr-1" />
                  )}
                  {botStatus?.botConfigured ? "Configured" : "Not Set"}
                </Badge>
              </div>
              <div className="flex items-center justify-between">
                <span>Admin IDs:</span>
                <Badge
                  variant={botStatus?.adminConfigured ? "default" : "destructive"}
                  className={botStatus?.adminConfigured ? "bg-green-600" : "bg-red-600"}
                >
                  {botStatus?.adminConfigured ? (
                    <CheckCircle className="w-3 h-3 mr-1" />
                  ) : (
                    <XCircle className="w-3 h-3 mr-1" />
                  )}
                  {botStatus?.adminConfigured ? "Configured" : "Not Set"}
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Webhook Setup Card */}
        <Card className="mb-8 bg-black/80 border-2 border-cyan-400 shadow-2xl">
          <CardHeader>
            <CardTitle className="text-cyan-400 font-orbitron">
              Setup Webhook
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-cyan-400 mb-2">
                  Webhook URL
                </label>
                <Input
                  type="url"
                  placeholder="https://yourapp.replit.app/api/telegram-webhook"
                  value={webhookUrl}
                  onChange={(e) => setWebhookUrl(e.target.value)}
                  className="bg-transparent border-2 border-cyan-400 text-cyan-400 placeholder:text-cyan-400/60"
                />
              </div>
              <Button
                onClick={handleSetupWebhook}
                disabled={setupWebhookMutation.isPending}
                className="bg-gradient-to-r from-cyan-400 to-blue-600 hover:from-cyan-500 hover:to-blue-700 text-black font-bold"
              >
                {setupWebhookMutation.isPending ? "Setting up..." : "Setup Webhook"}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Instructions Card */}
        <Card className="bg-black/80 border-2 border-cyan-400 shadow-2xl">
          <CardHeader>
            <CardTitle className="text-cyan-400 font-orbitron">
              Bot Setup Instructions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4 text-sm">
              <div>
                <h3 className="font-bold text-cyan-400 mb-2">1. Create Telegram Bot</h3>
                <ul className="space-y-1 text-cyan-400/70 ml-4">
                  <li>• Message @BotFather on Telegram</li>
                  <li>• Send /newbot and follow instructions</li>
                  <li>• Copy the bot token provided</li>
                </ul>
              </div>
              
              <div>
                <h3 className="font-bold text-cyan-400 mb-2">2. Current Configuration</h3>
                <div className="space-y-2">
                  <div className="bg-black/50 p-2 rounded border border-cyan-400/30">
                    <code className="text-cyan-400">TELEGRAM_BOT_TOKEN=7755543107:AAG5kuaQXqZAvbVv2UUQSN4qQ60IL5eaMWE</code>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="ml-2 p-1 h-6 w-6"
                      onClick={() => copyToClipboard("7755543107:AAG5kuaQXqZAvbVv2UUQSN4qQ60IL5eaMWE")}
                    >
                      <Copy className="w-3 h-3" />
                    </Button>
                  </div>
                  <div className="bg-black/50 p-2 rounded border border-cyan-400/30">
                    <code className="text-cyan-400">TELEGRAM_ADMIN_IDS=7877620348</code>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="ml-2 p-1 h-6 w-6"
                      onClick={() => copyToClipboard("7877620348")}
                    >
                      <Copy className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="font-bold text-cyan-400 mb-2">3. Get Your Telegram User ID</h3>
                <ul className="space-y-1 text-cyan-400/70 ml-4">
                  <li>• Message @userinfobot on Telegram</li>
                  <li>• Copy your User ID from the response</li>
                  <li>• Add it to TELEGRAM_ADMIN_IDS environment variable</li>
                </ul>
              </div>

              <div>
                <h3 className="font-bold text-cyan-400 mb-2">4. Bot Commands</h3>
                <ul className="space-y-1 text-cyan-400/70 ml-4">
                  <li>• <code>/start</code> - Show main menu</li>
                  <li>• <code>/adddb [username]</code> - Add new user to database</li>
                  <li>• <code>/adduser [username]</code> - Add new user (alias for adddb)</li>
                  <li>• <code>/help</code> - Show detailed help</li>
                </ul>
              </div>

              <div>
                <h3 className="font-bold text-cyan-400 mb-2">5. Example Usage</h3>
                <div className="space-y-2">
                  <div className="bg-black/50 p-2 rounded border border-cyan-400/30">
                    <code className="text-cyan-400">/start</code>
                  </div>
                  <p className="text-cyan-400/70 text-xs">Shows the main menu with all available options</p>
                  
                  <div className="bg-black/50 p-2 rounded border border-cyan-400/30">
                    <code className="text-cyan-400">/adddb john_doe</code>
                  </div>
                  <p className="text-cyan-400/70 text-xs">Creates user "john_doe" and sends credentials via Telegram</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}