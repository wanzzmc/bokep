import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Shield, Zap, Target, Bot } from "lucide-react";

export default function AuthPage() {
  const [, setLocation] = useLocation();
  const { user, loginMutation, registerMutation } = useAuth();
  const [loginData, setLoginData] = useState({ username: "", password: "" });
  const [registerData, setRegisterData] = useState({ username: "", password: "" });

  // Use effect to handle redirect after login
  useEffect(() => {
    if (user) {
      setLocation("/");
    }
  }, [user, setLocation]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    loginMutation.mutate(loginData);
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    registerMutation.mutate(registerData);
  };

  return (
    <div className="min-h-screen bg-black text-cyan-400 flex items-center justify-center">
      <div className="w-full max-w-md p-8">
        <Card className="bg-black/80 border-2 border-cyan-400 shadow-2xl backdrop-blur-sm">
          <CardHeader className="text-center">
            <div className="mx-auto mb-4 w-16 h-16 bg-gradient-to-br from-cyan-400 to-blue-600 rounded-full flex items-center justify-center">
              <Shield className="w-8 h-8 text-black" />
            </div>
            <CardTitle className="text-2xl font-bold text-cyan-400 font-orbitron tracking-wider">
              SYSTEM ACCESS
            </CardTitle>
            <p className="text-cyan-400/70 text-sm">
              Enter your credentials to continue
            </p>
          </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="login-username" className="text-cyan-400 font-orbitron">
                    Username
                  </Label>
                  <Input
                    id="login-username"
                    type="text"
                    value={loginData.username}
                    onChange={(e) => setLoginData({ ...loginData, username: e.target.value })}
                    className="bg-transparent border-2 border-cyan-400 text-cyan-400 placeholder:text-cyan-400/60 focus:border-cyan-400 focus:ring-cyan-400/50"
                    placeholder="Enter your username"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="login-password" className="text-cyan-400 font-orbitron">
                    Password
                  </Label>
                  <Input
                    id="login-password"
                    type="password"
                    value={loginData.password}
                    onChange={(e) => setLoginData({ ...loginData, password: e.target.value })}
                    className="bg-transparent border-2 border-cyan-400 text-cyan-400 placeholder:text-cyan-400/60 focus:border-cyan-400 focus:ring-cyan-400/50"
                    placeholder="Enter your password"
                    required
                  />
                </div>
                <Button
                  type="submit"
                  disabled={loginMutation.isPending}
                  className="w-full bg-gradient-to-r from-cyan-400 to-blue-600 hover:from-cyan-500 hover:to-blue-700 text-black font-bold font-orbitron tracking-wider"
                >
                  {loginMutation.isPending ? "AUTHENTICATING..." : "ACCESS SYSTEM"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    );
}
